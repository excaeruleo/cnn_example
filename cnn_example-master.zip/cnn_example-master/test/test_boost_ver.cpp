#include <boost/version.hpp>
#include <iostream>

int main() {
    std::cout << "Boost version: " << BOOST_VERSION << std::endl;
    return 0;
}


