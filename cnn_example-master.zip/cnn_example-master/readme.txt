Implement a simple neural network to recognize handwritten numbers.
