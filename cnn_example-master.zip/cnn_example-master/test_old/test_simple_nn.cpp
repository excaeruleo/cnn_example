// Test program to read a yaml file and generate a neural network accordingly

#include "yml_oarchive.hpp"
#include "yml_iarchive.hpp"

#include <boost/serialization/vector.hpp>
#include <boost/serialization/utility.hpp> // serialize pair
#include <boost/serialization/array.hpp>
#include <boost/serialization/set.hpp>
#include <boost/serialization/optional.hpp> // serialize boost::optional

#include<fstream>
#include<iostream>
#include<string>
#include<vector>
#include<math.h>

#include "typedef.hpp"
#include "neuron.hpp"
#include "layer.hpp"
#include "utils.hpp"

#define NVP(a) BOOST_SERIALIZATION_NVP(a) 

struct neural_network{
  int n_layers;
	std::vector< cnn::Layer > layers;
  std::string input_layer_type;
  std::vector<cnn::real_type> input_layer_values;
  std::string output_layer_type;
  std::vector<cnn::real_type> output_layer_values;

	template<class Ar>
	void serialize(Ar& ar, unsigned){
		ar & NVP(n_layers) & NVP(layers) & NVP(input_layer_type) & NVP(input_layer_values) & NVP(output_layer_type) & NVP(output_layer_values);
    assert(n_layers == layers.size());
    //layers[0].reinitialize(input_layer_type, input_layer_values);
    //layers[layers.size()-1].reinitialize(output_layer_type, output_layer_values);
	}
	bool operator==(neural_network const& nn_) const{return nn_.n_layers==n_layers;}

  // ostream operator
  friend std::ostream& operator<< (std::ostream& stream, const neural_network & nn) {

		std::cout << "layer_type = " << nn.n_layers << std::endl;
		std::cout << "input_layer_type = " << nn.input_layer_type << std::endl;
		for(int i = 0; i < nn.input_layer_values.size(); i ++)
			std::cout << nn.input_layer_values[i] << '\n';
		std::cout << "output_layer_type = " << nn.input_layer_type << std::endl;
		for(int i = 0; i < nn.output_layer_values.size(); i ++)
			std::cout << nn.output_layer_values[i] << '\n';

		for(int i = 0; i < nn.layers.size(); i ++)
			std::cout << nn.layers[i] << '\n';

    return stream;
  }

  bool initialize();
  void update_forward(void){
    
#ifdef DEBUG
		std::cout << layers[2];
#endif
		//layers[1].update_forward(layers[0], layers[2]);
    //for(int i = 1; i < layers.size()-1; i ++)
      //layers[i].update_forward();
#ifdef DEBUG
		std::cout << layers[2];
#endif
  }
  void update_backward(void) {
#ifdef DEBUG
    std::cout << layers[1];
#endif
    //layers[1].update_backward(layers[0], output_layer_values, layers[2]);
#ifdef DEBUG
    std::cout << layers[1];
#endif
  }  
};

bool neural_network::initialize(){

return true;

}

int main(){
	int n_layers;
	std::vector<std::vector<std::vector<int>>> layers;
	std::string input_layer_type;
	std::vector<int> input_layer_values;
	std::string output_layer_type;
	std::vector<int> output_layer_values;
  neural_network nn;

	{
    if(! cnn::check_if_file_exists("testinput/simple_nn.yaml") ){
       std::cerr << "File testinput/simple_nn.yaml doesn't exist" << std::endl;
       exit(1);
    }
      
		std::ifstream ifs{"testinput/simple_nn.yaml"};
		boost::archive::yml_iarchive yia{ifs};
		yia 
			>> NVP(n_layers)
			>> NVP(layers)
			>> NVP(input_layer_type)
			>> NVP(input_layer_values)
			>> NVP(output_layer_type)
			>> NVP(output_layer_values)
			>> NVP(nn)
		;
    ifs.close();

#ifdef DEBUG
		std::cout << "n_layers = " << n_layers << std::endl;
		std::cout << "input_layer_type = " << input_layer_type << std::endl;
		std::cout << "input_layer_values = " << input_layer_values << std::endl;
		for(int i = 0; i < input_layer_values.size(); i ++)
	  	std::cout << input_layer_values[i] << '\n';
#endif

    std::cout << "\n";
    std::cout << "Begin NN iteration...\n";
    std::cout << "\n";
    nn.update_forward();
    std::cout << nn.layers[2] ;
    
#ifdef DEBUG
    //std::cout << "n_layers = " << n_layers << std::endl;
    //std::cout << "output_layer_type = " << output_layer_type << std::endl;
    //for (int i = 0; i < output_layer_values.size(); i++) {
    //  std::cout << output_layer_values[i] << '\n';
    //}
    //std::cout << nn;
#endif
    nn.update_backward();
    //double last_J = 0;
    /*for (int i = 0; i < 2; i++) {
    nn.update_forward();
    //std::cout << "Output: " << input_layer_values[i] << std::endl;
    //std::cout << "Expected: " << output_layer_values[i] << std::endl;
    double J = 0.5 * pow((input_layer_values[i] - output_layer_values[i]), 2.0);
    std::cout << "Cost function: " << J << std::endl;
    if (abs(J - last_J) / J < pow(10, -6)) {
      break;
    }
    else {
      last_J = J;
    }
    nn.update_backward();
    }*/ 
	}
}
