sudo apt install -y libboost-dev   \
  libboost-doc libboost1.83-doc libboost-atomic1.83-dev libboost-chrono1.83-dev libboost-container1.83-dev libboost-context1.83-dev \
  libboost-contract1.83-dev libboost-coroutine1.83-dev libboost-date-time1.83-dev libboost-exception1.83-dev libboost-fiber1.83-dev \
  libboost-filesystem1.83-dev libboost-graph-parallel1.83-dev libboost-graph1.83-dev libboost-iostreams1.83-dev libboost-json1.83-dev \
  libboost-locale1.83-dev libboost-log1.83-dev libboost-math1.83-dev libboost-mpi-python1.83-dev libboost-mpi1.83-dev \
  libboost-nowide1.83-dev libboost-numpy1.83-dev libboost-program-options1.83-dev libboost-python1.83-dev libboost-random1.83-dev \
  libboost-regex1.83-dev libboost-serialization1.83-dev libboost-stacktrace1.83-dev libboost-system1.83-dev libboost-test1.83-dev \
  libboost-thread1.83-dev libboost-timer1.83-dev libboost-type-erasure1.83-dev libboost-url1.83-dev libboost-wave1.83-dev \
  libboost1.83-tools-dev libmpfrc++-dev libntl-dev
