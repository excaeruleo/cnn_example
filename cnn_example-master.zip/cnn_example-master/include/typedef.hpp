#ifndef TYPEDEF_HPP
#define TYPEDEF_HPP

#define NVP(a) BOOST_SERIALIZATION_NVP(a) 
namespace cnn{

  typedef unsigned int int_type;
  typedef float real_type;

};

#endif
