#include <../include/neuron.hpp>

int main(void) {

return 0;

}
