#include <opencv2/opencv.hpp>
#include <iostream>

using namespace std;
using namespace cv;

int render_image(const string & filename, Mat & image) {
  image = imread(filename, IMREAD_COLOR);
  if (image.empty()) {
    cout << "!!! imread failed !!!" << endl;
    exit(1);
  }
  Size sz = image.size();
  int width = sz.width;
  int height = sz.height;
  cout << "Image width: " << width << endl;
  cout << "Image height: " << height << endl;
  imshow("Display window", image);
  waitKey(0); 
  return 0;
}

int main(int argc, char *argv[]) {
  Mat image;
  render_image(argv[1], image);
}
