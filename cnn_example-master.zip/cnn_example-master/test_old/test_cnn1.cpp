// Test program to read a yaml file and generate a neural network accordingly

#include "yml_oarchive.hpp"
#include "yml_iarchive.hpp"

#include <boost/serialization/vector.hpp>
#include <boost/serialization/utility.hpp> // serialize pair
#include <boost/serialization/array.hpp>
#include <boost/serialization/set.hpp>
#include <boost/serialization/optional.hpp> // serialize boost::optional

#include<fstream>
#include<iostream>
#include<string>
#include<vector>
#include<math.h>

#include "typedef.hpp"
#include "connection.hpp"
#include "neuron.hpp"
#include "layer.hpp"
#include "utils.hpp"

#define NVP(a) BOOST_SERIALIZATION_NVP(a) 

struct neural_network{
  int n_layers;
	std::vector< cnn::Layer > layers;
  std::vector< cnn::Connection > connections;
  std::string input_layer_type;
  std::vector<cnn::real_type> input_layer_values;
  std::string output_layer_type;
  std::vector<cnn::real_type> output_layer_values;

	template<class Ar>
	void serialize(Ar& ar, unsigned){
		ar & NVP(n_layers) & NVP(layers) & NVP(input_layer_type) & NVP(input_layer_values) & NVP(output_layer_type) & NVP(output_layer_values);
    assert(n_layers == layers.size());
    //layers[0].reinitialize(input_layer_type, input_layer_values);
    //layers[layers.size()-1].reinitialize(output_layer_type, output_layer_values);
	}
	bool operator==(neural_network const& nn_) const{return nn_.n_layers==n_layers;}

  // ostream operator
  friend std::ostream& operator<< (std::ostream& stream, const neural_network & nn) {

		std::cout << "layer_type = " << nn.n_layers << std::endl;
		std::cout << "input_layer_type = " << nn.input_layer_type << std::endl;
		for(int i = 0; i < nn.input_layer_values.size(); i ++)
			std::cout << nn.input_layer_values[i] << '\n';
		std::cout << "output_layer_type = " << nn.input_layer_type << std::endl;
		for(int i = 0; i < nn.output_layer_values.size(); i ++)
			std::cout << nn.output_layer_values[i] << '\n';

		for(int i = 0; i < nn.layers.size(); i ++)
			std::cout << nn.layers[i] << '\n';

    return stream;
  }

  bool initialize();
  void update_forward(void){
    
#ifdef DEBUG
		std::cout << layers[1];
#endif
		layers[1].update_forward(layers[0], connections[1], layers[1]);
#ifdef DEBUG
		std::cout << layers[1];
#endif
  }
  void update_backward(void) {
#ifdef DEBUG
    std::cout << layers[1];
#endif
    //layers[1].update_backward(layers[0], output_layer_values, layers[2]);
#ifdef DEBUG
    std::cout << layers[1];
#endif
  }  
};

bool neural_network::initialize(){

	cnn::Layer input_layer = cnn::Layer(4); // make a input layer of 4 neurons.
	cnn::Layer output_layer = cnn::Layer(4); // make a output layer of 4 neurons.
	cnn::Connector w11 = cnn::Connector(1,1); // construct weight connector, there are 16 of them
	cnn::Connector w12 = cnn::Connector(1,2); // construct weight connector, there are 16 of them

	layers = {input_layer, output_layer};
	connections = {cnn::Connection({w11,w12}) }; // A single connection layer with 2 connectors.

	connections.resize(0);
	std::vector<cnn::Connector> weights;
	for (int i = 0; i < 4; i ++ ){
		for (int j = 0; j < 4; j ++ ){
			weights.push_back(cnn::Connector(i,j));
		}
	}
	connections = {cnn::Connection(weights)};

	return true;

}

int main(){

	neural_network nn;
	nn.initialize();

}
